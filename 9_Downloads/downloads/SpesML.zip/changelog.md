# SpesML Profile Change Log

**SpesML plugin version: 2021x Refresh1 (build 340)**
- Updated TVP:
    - Reduced TVP Interfaces to only the Technical Interfaces, but now with Channels (Task Interfaces are removed)
    - Added new Allocation Matrix for Port Allocation between Tasks and Execution Components

**SpesML plugin version: 2021x Refresh1 (build 337)**
- Fixed minor misspelling
- Updated TVP:
    - Improved Task To Execution Component Allocation Matrix
    - Fixed Validation/WF rules for Task Architectures and Execution Platforms

**SpesML plugin version: 2021x Refresh1 (build 336)**
- Updated TVP:
    - Added first draft of Task To Execution Component Allocation Matrix

**SpesML plugin version: 2021x Refresh1 (build 333)**
- Updated TVP:
    - Fixed missing interface possibilities

**SpesML plugin version: 2021x Refresh1 (build 323)**
- Updated TVP:
    - Updated TVP legend

**SpesML plugin version: 2021x Refresh1 (build 322)**
- Updated TVP:
    - Modified plugin template for TVP (regarding old diagram types)
    - Updated TVP legend

**SpesML plugin version: 2021x Refresh1 (build 320)**
- Updated TVP:
    - Reduced TVP Interfaces to just Technical and Task Interfaces (adjusted everything else to it)

**SpesML plugin version: 2021x Refresh1 (build 318)**
- Modified CustomDragAndDropConfig to allow specifying owners of the diagrams (needed for separating the different technical diagrams according to their owner elements)

**SpesML plugin version: 2021x Refresh1 (build 317)**
- Updated TVP:
    - Fixed Drag&Drop for new diagrams
    - Added Icon Handlers for other external components in TVP (besides technical components)

**SpesML plugin version: 2021x Refresh1 (build 314)**
- Updated TVP:
    - Added separate Internal Diagrams for Mechanical, Mechatronic and Electronic Components
    - Name fixes

**SpesML plugin version: 2021x Refresh1 (build 313)**
- Updated TVP:
    - Modified plugin template for TVP

**SpesML plugin version: 2021x Refresh1 (build 312)**
- Updated TVP:
    - Added Technical Context

**SpesML plugin version: 2021x Refresh1 (build 309)**
- Updated TVP:
    - Technical Interfaces are updated (as a first draft - not final yet)

**SpesML plugin version: 2021x Refresh1 (build 308)**
- Updated TVP:
    - New and updated icons for all TVP elements
    - Modified visualization order of elements in context menu

**SpesML plugin version: 2021x Refresh1 (build 299)**
- Updated TVP:
    - New package types besides technical package: software package, task architecture package, execution platform package

**SpesML plugin version: 2021x Refresh1 (build 294)**
- Updated TVP:
    - Current diagrams: Technical, Software, Task Architecture, Execution Platform
    - Current technical components: Technical Component, Software Component, Mechanical Component, Electronic Component, Mechatronic Component, Task Architecure, Task, Execution Platform, Execution Component, Communication Component
    - Adjusted remaining specification to these new artifacts (like Drag&Drop, etc.)
    - No adjustment of the interfaces/ports yet!

**SpesML plugin version: 2021x Refresh1 (build 216)**
- Integrated initial version of SpesMLFunctionsLanguagePlugin: Code Blocks defining functions in the SpesML functions language can be validated (e.g. Syntax, correct type usage, etc.)

**SpesML plugin version: 2021x Refresh1 (build 201)**
- Advanced message box for not recommended drag/drop actions

**SpesML plugin version: 2021x Refresh1 (build 200)**
- Fixed wrong SpesML Hardware Internal Component Diagram reference in descriptor.xml
- SpesMLCustomDragAndDropPlugin: Added a message box when dragging & dropping an not allowed element
- SpesMLCustomDragAndDropPlugin: Simplified plugin code

**SpesML plugin version: 2021x Refresh1 (build 191)**
- Added related part element for each component to all existing Drag&Drop configurations

**SpesML plugin version: 2021x Refresh1 (build 190)**
- Fixed SpesMLCustomDragAndDropPlugin regarding separation of diagram configs and support of multiple configs for the same diagram
- Added drag&drop configs for TVP (software and hardware diagrams) 

**SpesML plugin version: 2021x Refresh1 (build 186)**
- Added initial version of SpesMLCustomDragAndDropPlugin that provides configuration possibilities for SpesML diagrams. This enables to prevent 
  unwanted elements to be dropped onto SpesML diagrams.
- Initial configuration provided for Logical Viewpoint
- Updated other plugins for better *.jar file naming

**SpesML plugin version: 2021x Refresh1 (build 173)**
- Updated TVP after brainstorming meeting (return old components like mechanical and electronics and create a new port structure for them):
    - updated icons
    - updated legend template
    - updated validation rules
    - updated stereotypes
    - updated diagrams

**SpesML plugin version: 2021x Refresh1 (build 166)**
- Updated legend template for LVP

**SpesML plugin version: 2021x Refresh1 (build 165)**
- Added initial version of SpesMLVisualizationPlugin that provides enhanced visualization possibilities
- Integrated initial version of SpesMLSysmboltablePlugin (RWTH Aachen)
- Updated Logical Context:
    - updated icons
    - External is now an enumeration (yes/no) in order to automatically change the icon
    - External = yes will now also color the element differently
    - Changed how Logical Actor is displayed
    - Changed several settings e.g. Smart Manipulators

**SpesML plugin version 2021x - 1.150**
- Added legend template for LVP (Logical Elements)
- Added first draft for logical context, e.g.:
    - added logical actor
    - added logical context (element), still with already existing logical IBD
    - added 'external' property to logical component parts

**SpesML plugin version 2021x - 1.137**
- Added more custom (binary) validation rules for SpesML Validation Plugin

**SpesML plugin version 2021x - 1.131**
- Small error fixes and extensions
- Added SpesML Validation Plugin
- Added Custom Validation Rules
- Additional customizations based on defined Well-Formedness Rules

**SpesML plugin version 2021x - 1.127**
- Added first draft for TVP based on internal document, e.g.:
    - two separate diagrams: software and execution platform
    - two separate interfaces types: software and hardware
    - three different interfaces: software, hardware and communication
    - changed the four previous components (software, electronic, mechanical, mechatronic) into four new ones: software vs. execution platform with execution and communication component (parts)
- Updated old icons and color schemata and created new ones
- Added legend template for TVP (Technical Elements)

**SpesML plugin version 2021x - 1.105**
- Fixed ant build error due to missing bin folder in SpesMLWebsiteLinkPlugin
- Minor naming corrections in TVP

**SpesML plugin version 2021x - 1.103**
- Removed the no longer needed "SpesML Technical Component Definition Diagram" definition
- All diagrams now show the SpesML Name
- The Context Kind (e.g. class, ...) on diagrams is no longer shown 
- All SpesML diagrams are now grouped into a single SpesML category

**SpesML plugin version 2021x - 1.101**
- Added "SpesML Internal Component Diagram" definition 

**SpesML plugin version 2021x - 1.100**
- Removed Generalization to PartProperty as this will result in showing "Part Property" as the element type instead of e.g. "Logical Component Part"

**SpesML plugin version 2021x - 1.99**
- Small code refactorings and improvements based on code quality assessment (Teamscale @ qualicen)

**SpesML plugin version 2021x - 1.91**
- Added a new plugin (SpesMLStereotypesPlugin) to automatically apply stereotypes when creating Parts (Properities) of SpesML elements

**SpesML plugin version 2021x - 1.85**
- Removed "Place on Palette" for elements of the Technical Viewpoint
- Allowed "Value Property" elements to be create below Functions, Logical Components and all Technical Components

**SpesML plugin version 2021x - 1.83**
- ~InterfaceBlock is now no longer shown under "Create Element" on Model level
- Added a new SpesML StateMachine Element and SpesML State Machine Diagram to the Universal Interface Model
- Below Functions, Logical Components as well as all Technical Components a SpesML State Machine can now be created
- Functions, Logical Components as well as all Technical Components now show the Classifier Behavior

**SpesML plugin version 2021x - 1.77**
- Updated settings of all interfaces to automatically "Show Type"

**SpesML plugin version 2021x - 1.76**
- Existing **Universal Interface Stereotypes** changed to _Abstract_ stereotypes (except SpesML Channel which is a common stereotype)
- Added the **SpesML Logical Interface Type Package** - Logial Interface Types can only be created below this package
- Added the **SpesML Logical Interface**
- Added the **SpesML Functional Interface Type Package** - Functional Interface Types can only be created below this package
- Added the **SpesML Functional Interface**
- Added the **SpesML Technical Interface Type Package** - Technical Interface Types can only be created below this package
- Added the **SpesML Technical Interface**
- Updated SpesML Model Template to include newly defined interface type packages by default
- All interfaces can only be typed by their corresponding interface types
